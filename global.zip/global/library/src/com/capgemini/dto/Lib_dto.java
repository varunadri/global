package com.capgemini.dto;

public class Lib_dto {
 
	private static String student_id;
	private static int book_id;
	
	public Lib_dto()
	{
		
	}
	
	public int getBook_id() {
		return book_id;
	}


	public void setBook_id(int book_id) {
		this.book_id = book_id;
	}

	public String getStudent_id() {
		return student_id;
	}

	public void setStudent_id(String Student_id) {
		this.student_id = Student_id;
	}
	
	

	
	public Lib_dto(String student_id, int book_id)
	{
		this.student_id = student_id;
		this.book_id = book_id;
		
	}

	public String toString()
	 {
		return "data entered by you is[student_id=" + student_id + ",book_id=" + book_id + "]" ;
	}
	
	
	
	
}
