package com.capgemini.pi;
import com.capgemini.exception.FilenotfoundException;



import java.sql.SQLException;

import java.util.Scanner;
import com.capgemini.dto.Lib_dto;
import com.capgemini.librarian_dto.Addview_book;
import com.capgemini.librarian_dto.Del_book;
import com.capgemini.librarian_dto.Reg_user;
import com.capgemini.servicelayer.Lib_serviceimpl;
public class Libmain

{

	public static void main(String[] args) throws FilenotfoundException,SQLException,ClassNotFoundException
	{
		
		Lib_serviceimpl serve= new Lib_serviceimpl();
		Scanner in = new Scanner(System.in);
		System.out.println("welcome to library management system");
		System.out.println("choose an option");
		System.out.println("1. student");
		System.out.println("2. Librarian");
		System.out.println("3. Exit");
		int choice= in.nextInt();
		 
			switch(choice)
			//student option chosen
		
		{
	case 1:
		
				System.out.println("welcome student");
				Scanner p = new Scanner(System.in);
				System.out.println("select an option");
				System.out.println("1. issue a book");
				System.out.println("2. return a book");
				int option = p.nextInt();
				
				switch(option)
				{
				
				// issue a book
				
				case 1:
				 {
					Scanner q = new Scanner(System.in);

					Lib_dto opt= new Lib_dto();
					Lib_dto fs= new Lib_dto();
					System.out.println("enter the book id");
					opt.setBook_id(q.nextInt());
					System.out.println("enter the student id");
					opt.setStudent_id(q.next());
					int regid= serve.Insertissuedetails(fs);
					System.out.println("book issued with issue id"+ regid);
				p.close();
				    break;				
				}
				
			

				case 2:
				{
					Lib_dto opt1= new Lib_dto();
					Scanner q1 = new Scanner(System.in);
					System.out.println("enter book id");
					opt1.setBook_id(q1.nextInt());
					serve.returnbook(opt1);
					System.out.println("book has been returned");

					
					
					break;
				}
				}
break;
		
			
	case 2:
			{
				System.out.println("welcome librarian");
				Scanner l= new Scanner(System.in);
				System.out.println("choose an option");
				System.out.println("1. register as user");
				System.out.println("2. add a book");
				System.out.println("3. delete a book");
				//System.out.println("4. view books in inventory"); 
				int lib_option= l.nextInt();
				Scanner ch = new Scanner(System.in);
					switch(lib_option)
					{
					// add a book
					case 2:
						Addview_book ab= new Addview_book();
						System.out.println("enter bookid");
						ab.setBook_id(ch.nextInt());
						System.out.println("enter bookname");
						ab.setBook_name(ch.next());
						System.out.println("enter author1");
						ab.setAuthor1(ch.next());
						System.out.println("enter author2");
						ab.setAuthor2(ch.next());
						System.out.println("enter publication");
						ab.setPublication(ch.next());
						System.out.println("enter yearofpublication");
						ab.setYearofpublication(ch.next());
						int add= serve.Addview(ab);
						System.out.println("your book has been added with id"+add);
						break;
					
					//register as a user
					case 1:
						Reg_user ruu= new Reg_user();
						Scanner ru= new Scanner(System.in);
						System.out.println("enter user_id");
						ruu.setUser_id(ru.next());
						System.out.println("enter user_name");
						ruu.setUser_id(ru.next());
						System.out.println("enter password");
						ruu.setPassword(ru.next());
						System.out.println("enter emailid");
						ruu.setEmail_id(ru.next());
						serve.Register(ruu);
						System.out.println("thanks for registering ");
						
						break;
					
					//delete a book
					
					case 3:
						Del_book db= new Del_book();
						Scanner db1= new Scanner(System.in);
						System.out.println("enter book_id");
						db.setBook_id(db1.nextInt());
						System.out.println("enter book_name");
						db.setBook_name(db1.next());
						serve.Delete(db);
						System.out.println("book has been deleted");
						break;
						
						//view books in inventory
					
					/*case 4:
						Addview_book ab1= new Addview_book();
						Scanner vb= new Scanner(System.in);
						System.out.println("enter book_id");
						ab1.setBook_id(vb.nextInt());
						System.out.println("enter book_name");
						ab1.setBook_name(vb.next());
					
						break;*/	
					}
			}
		
		
   case 3: 
	{
		System.out.println("Thank you");
		System.exit(0);
		break;
	}
	
	
  default :

    {
       System.out.println("Invalid choice");
       in.close();	
       break;
    }
	
		}	
			}
}


			
	
	
	
	
	
	
	
	
	
	
	



