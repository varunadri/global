package Test;  

import static org.junit.Assert.*;
import static org.junit.Assert.assertTrue;

import java.sql.SQLException;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.capgemini.dto.Lib_dto;
import com.capgemini.dao.Lib_daoimpl;
import com.capgemini.exception.FilenotfoundException;


public class LibraryDaoTest {

    static Lib_daoimpl dao;
    static Lib_dto lib_dto;

    @BeforeClass
    public static void initialize() {
        dao = new Lib_daoimpl();
        lib_dto = new Lib_dto();
    }

    @Test
    public void testInsertissuedetails() throws FilenotfoundException, ClassNotFoundException, SQLException {

        assertNotNull(dao.Insertissuedetails(lib_dto));
    }
    
    /************************************
     * Test case for insertIssueDetails()
     * @throws SQLException 
     * @throws ClassNotFoundException 
     * 
     ************************************/

    @Ignore
    @Test
    public void testInsertissuedetails1() throws FilenotfoundException, ClassNotFoundException, SQLException {
        assertEquals(1001, dao.Insertissuedetails(lib_dto));
    }

    /************************************
     * Test case for addIssuetDetails()
     * 
     ************************************/

    @Test
    public void testInsertissuedetails2() throws FilenotfoundException {
        
    	lib_dto.setBook_id(1001);
    	lib_dto.setStudent_id("stud01");
    	
        assertTrue("Data Inserted successfully");
                //Integer.parseInt(dao.Insertissuedetails(lib_dto)));

    }

	private void assertTrue(String string) {
		// TODO Auto-generated method stub
		
	}
}