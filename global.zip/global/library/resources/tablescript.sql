 create table re_user(user_id number,User_name number,Password varchar2(20),Email_id varchar2(30));
 create table books_inventory( Book_id number, Book_name varchar2(20),  Author1 varchar2(20), Author2 varchar2(20),Publication varchar2(20), Yearofpublication varchar2(20));
 create table books_registration( book_id number, student_id varchar2(20));
 create sequence regid start with 1;